### Name: print.list.pairs
### Title: Support functions
### Aliases: print.list.pairs print summary format
### Keywords: interface database

### ** Examples
## Not run: 
##D print.list.pairs(list(a =1, b = 2))
## End(Not run)



