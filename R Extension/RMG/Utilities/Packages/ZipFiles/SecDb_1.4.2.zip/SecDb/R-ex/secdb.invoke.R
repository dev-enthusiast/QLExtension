### Name: secdb.invoke
### Title: Invoke a SecDb Library Function
### Aliases: secdb.invoke


### ** Examples

library(SecDb)

secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Get the curve data using the tsdb utility functions
curveData = secdb.invoke("_Lib ELEC Matlab Dispatch Fns", "TSDB::read",
  "PRC_NG_EXCHANGE_0706", Sys.Date()-50, Sys.Date()-1)
print(head(data.frame(curveData)))

##Won't work!  It will print a SecDb error because not all arguments were passed
res1 <- secdb.invoke("_lib elec spread regression fns", "SpreadUtil::FuturesStrip",
             "Commod NG exchange", as.Date("2007-06-18"))
print( head( data.frame(res1) ) )

##Now it will run! :) (Notice the extra NULL for the VT argument)
res1 <- secdb.invoke("_lib elec spread regression fns", "SpreadUtil::FuturesStrip",
             "Commod NG exchange", as.Date("2007-06-18"), NULL)
print( head( data.frame(res1) ) )

##This creates an array with 2 structure elements
Locations <- list( list(loc="COMMOD WTI EXCHANGE", name="WTI"),
                   list(loc="COMMOD NG Exchange", name="NG") )
last.mark <- Sys.Date()
yesterday <- Sys.Date()-1
dateTill  <- as.Date("2009-12-01")
useClose  <- TRUE

x <- secdb.invoke("_lib elec dly fut changes", "DlyFutChanges::GetFutStrip", 
  Locations, last.mark, yesterday, dateTill, useClose, "CPS")




