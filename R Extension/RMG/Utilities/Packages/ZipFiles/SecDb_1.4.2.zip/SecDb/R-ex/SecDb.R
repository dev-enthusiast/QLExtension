### Name: SecDb
### Title: R to SecDb Library
### Aliases: SecDb-package SecDb
### Keywords: package

### ** Examples

library(SecDb)

secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

startDate = Sys.Date() - 50
endDate = Sys.Date() - 1

##Read some curve data from TsDb
curveData = tsdb.readCurve( curveName="PRC_NG_Exchange_0706", 
  startDate=startDate, endDate=endDate )
print(head(curveData))

##Read a time based curve from TsDb
curveData2 = tsdb.readCurve( "nepool_load_hist", startDate, endDate )
print(head(curveData2))

curveInfo =  tsdb.getSymbolInfo( "PRC_NG_Exchange_0706" ) 
print(curveInfo)

##Can also use Slang evaluator
curveInfo2 = secdb.evaluateSlang( 'TsdbSymbolInfo("PRC_NG_EXCHANGE_0706")' )
print(curveInfo2)

##Get a given value type from a specified security
valueType = secdb.getValueType("Bal Close Attrition AcqCost", 
  "Date Created")
print(secdb.convertTime(valueType))

valueType2 = secdb.getValueType("Bal Close FrtMarks Config", "Contents")
print(valueType2)

##Returns null for invalid security or value type
badValueType = secdb.getValueType("Incorrect Security", "Bad Value")




