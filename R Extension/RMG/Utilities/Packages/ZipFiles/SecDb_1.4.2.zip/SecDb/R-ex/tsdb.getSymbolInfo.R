### Name: tsdb.getSymbolInfo
### Title: Get Information on a TsDb Symbol
### Aliases: tsdb.getSymbolInfo


### ** Examples


secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Returns a list object of all specified symbol info.  
curveInfo =  tsdb.getSymbolInfo( "PRC_NG_Exchange_0706" ) 
print(curveInfo)




