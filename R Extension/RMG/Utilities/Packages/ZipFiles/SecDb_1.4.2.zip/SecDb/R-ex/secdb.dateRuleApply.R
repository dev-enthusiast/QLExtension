### Name: secdb.dateRuleApply
### Title: Apply A SecDb Date Rule To An R Date
### Aliases: secdb.dateRuleApply


### ** Examples

library(SecDb)

secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Get the curve data using the tsdb utility functions
plusOneBusinessDay = secdb.dateRuleApply(Sys.Date(), "+1b")
print(plusOneBusinessDay)




