### Name: secdb.evaluateSlang
### Title: Evaluate SecDb Slang Code
### Aliases: secdb.evaluateSlang


### ** Examples

library(SecDb)

secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Get a given value type from a specified security
slangCode = 'GetValue("Bal Close Attrition AcqCost", "Date Created")'
valueType = secdb.evaluateSlang( slangCode )




