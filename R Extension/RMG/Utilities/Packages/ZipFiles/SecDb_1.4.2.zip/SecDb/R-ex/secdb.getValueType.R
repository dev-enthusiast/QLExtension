### Name: secdb.getValueType
### Title: Returning a Value Type From SecDb
### Aliases: secdb.getValueType


### ** Examples

library(SecDb)

secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Get a given value type from a specified security
valueType = secdb.getValueType("Bal Close Attrition AcqCost",
  "Date Created")
print(secdb.convertTime(valueType))

##This returns an R list representing the SecDb Structure object
valueType2 = secdb.getValueType("Bal Close FrtMarks Config", "Contents")
print ("Got Contents of Bal Close FrtMarks Config")




