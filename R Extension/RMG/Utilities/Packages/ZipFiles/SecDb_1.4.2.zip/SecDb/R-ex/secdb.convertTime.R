### Name: secdb.convertTime
### Title: Convert a SecDb Time to an R Time
### Aliases: secdb.convertTime


### ** Examples

library(SecDb)

## The string used is a standard SecDb database path
secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")

##Get a given value type from a specified security
valueType = secdb.getValueType("Bal Close Attrition AcqCost",
  "Date Created")
print(secdb.convertTime(valueType))




