### Name: tsdb.readCurve
### Title: Read a curve from the TsDb
### Aliases: tsdb.readCurve


### ** Examples

  secdb.setDatabase("!Bal Prod 1;ReadOnly{!Bal Prod 2}")
  
  startDate = Sys.Date() - 50
  endDate = Sys.Date() - 1
  
  ##A daily curve (SecDb type: Curve)
  curveData = tsdb.readCurve( curveName="PRC_NG_Exchange_0706", startDate=startDate, endDate=endDate )
  print(head(curveData))
  
  ##An hourly curve (SecDb type: TCurve)
  curveData2 = tsdb.readCurve( "nepool_load_hist", startDate, endDate )
  print(head(curveData2))



