### Name: melt.cast_matrix
### Title: Melt cast matrices
### Aliases: melt.cast_matrix
### Keywords: internal

### ** Examples



