### Name: rescaler.data.frame
### Title: Rescale a data frame
### Aliases: rescaler.data.frame
### Keywords: internal

### ** Examples



