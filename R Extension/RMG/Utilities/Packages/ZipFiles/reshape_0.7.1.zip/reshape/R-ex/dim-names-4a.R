### Name: dim.names
### Title: Dimension names
### Aliases: dim.names
### Keywords: internal

### ** Examples



