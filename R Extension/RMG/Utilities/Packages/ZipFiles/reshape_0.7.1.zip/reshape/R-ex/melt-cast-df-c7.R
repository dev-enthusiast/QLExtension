### Name: melt.cast_df
### Title: Melt cast data.frames
### Aliases: melt.cast_df
### Keywords: internal

### ** Examples



