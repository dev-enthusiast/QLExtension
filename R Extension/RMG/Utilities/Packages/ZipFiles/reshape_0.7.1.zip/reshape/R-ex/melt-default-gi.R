### Name: melt.default
### Title: Default melt function
### Aliases: melt.default
### Keywords: internal

### ** Examples



