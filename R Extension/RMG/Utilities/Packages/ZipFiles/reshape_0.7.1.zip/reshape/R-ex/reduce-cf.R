### Name: reduce
### Title: Reduce dimensions
### Aliases: reduce
### Keywords: internal

### ** Examples



