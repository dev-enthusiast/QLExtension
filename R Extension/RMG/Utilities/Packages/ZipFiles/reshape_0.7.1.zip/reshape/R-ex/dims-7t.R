### Name: dims
### Title: Dimensions
### Aliases: dims
### Keywords: internal

### ** Examples



