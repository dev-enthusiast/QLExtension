### Name: compact
### Title: Compact list
### Aliases: compact
### Keywords: manip

### ** Examples



