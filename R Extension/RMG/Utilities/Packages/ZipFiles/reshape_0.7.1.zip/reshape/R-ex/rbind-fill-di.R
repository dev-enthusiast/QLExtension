### Name: rbind.fill
### Title: Rbind fill
### Aliases: rbind.fill
### Keywords: manip

### ** Examples



