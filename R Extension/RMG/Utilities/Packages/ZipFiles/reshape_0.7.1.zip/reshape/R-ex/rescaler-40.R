### Name: rescaler
### Title: Rescaler
### Aliases: rescaler
### Keywords: manip

### ** Examples



