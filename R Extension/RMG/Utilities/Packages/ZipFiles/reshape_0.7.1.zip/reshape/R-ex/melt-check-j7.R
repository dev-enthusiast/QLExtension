### Name: melt_check
### Title: Melt check.
### Aliases: melt_check
### Keywords: internal

### ** Examples



