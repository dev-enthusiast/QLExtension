### Name: vdim
### Title: Dimensions
### Aliases: vdim
### Keywords: internal

### ** Examples



