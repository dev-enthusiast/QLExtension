### Name: merge_all
### Title: Merge together a series of data.frames
### Aliases: merge_all
### Keywords: manip

### ** Examples



