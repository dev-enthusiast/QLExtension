### Name: sqlTables
### Title: List Tables on an ODBC Database
### Aliases: sqlTables
### Keywords: IO database

### ** Examples

## Not run: 
##D channel <- odbcConnect("test")
##D sqlTables(channel, "USArrests")
##D ## MySQL example
##D ##   Table_qualifer Table_owner Table_name Table_type     Remarks
##D ##1                             usarrests      TABLE MySQL table
##D ## Microsoft Access example
##D ##      TABLE_CAT TABLE_SCHEM        TABLE_NAME   TABLE_TYPE REMARKS
##D ##1 C:\bdr\test        <NA> MSysAccessObjects SYSTEM TABLE    <NA>
##D ##2 C:\bdr\test        <NA>          MSysACEs SYSTEM TABLE    <NA>
##D ##3 C:\bdr\test        <NA>       MSysObjects SYSTEM TABLE    <NA>
##D ##4 C:\bdr\test        <NA>       MSysQueries SYSTEM TABLE    <NA>
##D ##5 C:\bdr\test        <NA> MSysRelationships SYSTEM TABLE    <NA>
##D ##6 C:\bdr\test        <NA>             hills        TABLE    <NA>
##D ##7 C:\bdr\test        <NA>         USArrests        TABLE    <NA>
##D close(channel)
## End(Not run)


