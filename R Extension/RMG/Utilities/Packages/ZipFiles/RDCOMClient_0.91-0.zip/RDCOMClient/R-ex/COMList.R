### Name: COMList
### Title: Create an instance of COMList class
### Aliases: COMList
### Keywords: interface

### ** Examples





