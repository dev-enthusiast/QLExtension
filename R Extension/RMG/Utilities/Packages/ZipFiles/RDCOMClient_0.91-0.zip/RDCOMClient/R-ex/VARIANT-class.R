### Name: VARIANT-class
### Title: Reference to a C-level VARIANT object
### Aliases: VARIANT-class CurrencyVARIANT-class DateVARIANT-class
### Keywords: classes

### ** Examples





