### Name: SCOMErrorInfo-class
### Title: S version of COM Error structure
### Aliases: SCOMErrorInfo-class
### Keywords: classes

### ** Examples




