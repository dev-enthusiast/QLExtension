### Name: COMList-class
### Title: COMList collection types
### Aliases: COMList-class [[,COMList,numeric-method
###   [[<-,COMList,numeric-method lapply,COMList-method
###   length,COMList-method sapply,COMList-method
### Keywords: classes

### ** Examples

## Not run: 
##D   e = COMCreate("Excel.Application")
##D   e$Workbooks()$Add()
##D   e$Workbooks()$Add()
##D 
##D   l = COMList(e$Workbooks())
##D   length(l)  # should be 2
##D   l[[1]]  # First Workbook
##D 
##D   setClass("Workbooks", contains = "COMTypedList")
##D   setClass("Workbook", contains = "COMIDispatch")
##D 
##D   l = COMList(e$Workbooks, "Workbooks")
##D   l[[1]]  # class is "Workbook"
## End(Not run)



