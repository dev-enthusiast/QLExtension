### Name: COMCreate
### Title: Create a COM object
### Aliases: COMCreate getCOMInstance
### Keywords: interface

### ** Examples


## Not run: 
##D  COMCreate("Excel.Application")
##D  getCOMInstance("{000208D5-0000-0000-C000-000000000046}")
## End(Not run)



