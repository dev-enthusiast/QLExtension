### Name: .COMInit
### Title: Activate and de-activate COM facilities in R
### Aliases: .COMInit
### Keywords: interface

### ** Examples

 .COMInit()
 .COMInit(TRUE)

 .COMInit(FALSE)



