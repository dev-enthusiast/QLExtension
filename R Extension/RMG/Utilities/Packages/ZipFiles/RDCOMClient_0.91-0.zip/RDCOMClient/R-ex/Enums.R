### Name: DispatchMethods
### Title: S-level constants
### Aliases: DispatchMethods
### Keywords: datasets

### ** Examples

## Not run: 
##D 
## End(Not run)



