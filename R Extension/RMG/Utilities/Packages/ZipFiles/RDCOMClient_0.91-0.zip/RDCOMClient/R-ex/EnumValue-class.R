### Name: EnumValue-class
### Title: A class to represent a value of an enumerated constant
### Aliases: EnumValue-class show,EnumValue-method
### Keywords: classes

### ** Examples


   # Define a new Enumeration class. 
 setClass("Color", contains = "EnumValue")
       # Define the enumeration definition table.
 ColorEnum = c(Red = 1, Green = 2, Blue = 3)
 storage.mode(ColorEnum) = "integer"

  # Set the coercion methods to take a number or a string 
  # to this class type.
 setAs("character", "Color",
         function(from)
            EnumValue(from, new("Color")))

 setAs("numeric", "Color",
         function(from)
            EnumValue(from, new("Color")))

   # Now we can use this class.
  as(1, "Color")
  as("Red", "Color")

  as("Blue", "Color")
 
    # These should give errors, so we enclose them in a call to try. 
  try(as("Orange", "Color"))
  try(as(20, "Color"))



