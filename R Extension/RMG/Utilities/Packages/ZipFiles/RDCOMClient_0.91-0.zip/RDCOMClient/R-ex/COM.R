### Name: .COM
### Title: Full access to client COM invocation
### Aliases: .COM
### Keywords: interface

### ** Examples


 e <- COMCreate("Excel.Application")
 books <- e[["Workbooks"]]
 books$Add()
 
  # Now for the example!
 books$Item(1)

 sheets <- e[["Sheets"]]
 sheets$Item(1)
## Not run: 
##D   # We can index the list of sheets by sheet name.
##D   # This is not run here as the name is different for 
##D   # different languages.  
##D  sheets$Item("Sheet1")
## End(Not run)

# Now tidy up.
 e$Quit()
 rm(list = c("books", "e", "sheets"))
 gc()

## Not run: 
##D o = COMCreate("Excel.Application")
##D 
##D .COM(o, "Count", .dispatch = 2, .ids = id)
## End(Not run)



