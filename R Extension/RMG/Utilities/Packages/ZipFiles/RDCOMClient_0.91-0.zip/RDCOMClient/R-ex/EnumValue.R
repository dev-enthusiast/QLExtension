### Name: EnumValue
### Title: Create instance of enumeration value class in R
### Aliases: EnumValue EnumValue,character,numeric,EnumValue-method
###   EnumValue,character,EnumValue,ANY-method
###   EnumValue,numeric,EnumValue,ANY-method
###   EnumValue,character,missing,EnumValue-method
###   EnumValue,numeric,missing,EnumValue-method EnumValue,-method
### Keywords: programming interface

### ** Examples




