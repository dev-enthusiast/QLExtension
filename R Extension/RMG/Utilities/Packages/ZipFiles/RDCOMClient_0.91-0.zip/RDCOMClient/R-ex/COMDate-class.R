### Name: COMDate-class
### Title: Classes for representing COM VARIANT values as numbers
### Aliases: COMDate-class COMCurrency-class COMDecimal-class HResult-class
### Keywords: classes

### ** Examples




