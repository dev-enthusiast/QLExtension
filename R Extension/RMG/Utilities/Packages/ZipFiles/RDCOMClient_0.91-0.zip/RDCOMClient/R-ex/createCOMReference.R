### Name: createCOMReference
### Title: Creates S object for COM reference
### Aliases: createCOMReference
### Keywords: interface

### ** Examples





