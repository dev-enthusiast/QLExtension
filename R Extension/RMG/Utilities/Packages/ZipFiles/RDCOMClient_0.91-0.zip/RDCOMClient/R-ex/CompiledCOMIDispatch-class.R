### Name: CompiledCOMIDispatch-class
### Title: DCOM Interface object with knowledge of its methods and their
###   types.
### Aliases: CompiledCOMIDispatch-class $,CompiledCOMIDispatch-method
###   $<-,CompiledCOMIDispatch,character-method
###   [[,CompiledCOMIDispatch,character-method
### Keywords: classes

### ** Examples





