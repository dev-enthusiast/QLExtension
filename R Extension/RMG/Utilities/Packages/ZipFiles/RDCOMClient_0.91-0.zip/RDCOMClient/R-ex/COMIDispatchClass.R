### Name: COMIDispatch-class
### Title: Representation of generic COM object in R
### Aliases: COMIDispatch-class IUnknown-class $<-,COMIDispatch,ANY-method
###   [[<-,COMIDispatch,character-method [[<-,COMIDispatch,numeric-method
### Keywords: classes

### ** Examples





