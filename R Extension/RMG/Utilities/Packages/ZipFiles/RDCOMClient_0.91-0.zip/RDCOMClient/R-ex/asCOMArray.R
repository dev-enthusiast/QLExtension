### Name: asCOMArray
### Title: Create COM SAFEARRAY from R matrix
### Aliases: asCOMArray
### Keywords: interface programming

### ** Examples

## Not run: 
##D   r = sheet$Range("A1:C10")
##D   r[["Value"]] <- asCOMArray(matrix(rnorm(30, 10, 3)))
## End(Not run)



