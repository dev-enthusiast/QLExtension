### Name: getCLSID
### Title: Get the UUID/GUID from the human-readable name of an
###   application.
### Aliases: getCLSID
### Keywords: programming interface

### ** Examples

  getCLSID("Excel.Application")



