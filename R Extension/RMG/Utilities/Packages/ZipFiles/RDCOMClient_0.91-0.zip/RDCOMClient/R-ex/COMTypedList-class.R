### Name: COMTypedList-class
### Title: Classes for representing DCOM objects that have list-like
###   facilities
### Aliases: COMTypedList-class COMTypedNamedList-class
###   [[,COMTypedList,ANY-method
### Keywords: classes

### ** Examples





