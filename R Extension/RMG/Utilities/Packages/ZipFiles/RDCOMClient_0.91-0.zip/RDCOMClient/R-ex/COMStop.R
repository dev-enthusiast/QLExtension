### Name: COMStop
### Title: General Error function for COM errors
### Aliases: COMStop
### Keywords: programming

### ** Examples

## Not run: 
##D    COMStop("A fake error message", 1, "FakeCOMError")
## End(Not run)



