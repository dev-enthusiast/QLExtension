### Name: odbcGetInfo
### Title: Request Information on an ODBC Connection
### Aliases: odbcGetInfo
### Keywords: IO database

### ** Examples
## Not run: 
##D odbcGetInfo(channel) # under Windows XP
##D ## MySQL returned
##D              DBMS_Name               DBMS_Ver        Driver_ODBC_Ver
##D                "MySQL"           "4.0.20a-nt"                "03.51"
##D       Data_Source_Name            Driver_Name             Driver_Ver
##D              "testdb3"          "myodbc3.dll"             "03.51.09"
##D               ODBC_Ver            Server_Name
##D           "03.52.0000" "localhost via TCP/IP"
##D ## MS Access returned
##D        DBMS_Name         DBMS_Ver  Driver_ODBC_Ver Data_Source_Name
##D         "ACCESS"     "04.00.0000"          "03.51"        "testacc"
##D      Driver_Name       Driver_Ver         ODBC_Ver      Server_Name
##D   "odbcjt32.dll"     "04.00.6304"     "03.52.0000"         "ACCESS"
##D ## MSDE 2000 returned
##D              DBMS_Name               DBMS_Ver        Driver_ODBC_Ver
##D "Microsoft SQL Server"           "08.00.0760"                "03.52"
##D       Data_Source_Name            Driver_Name             Driver_Ver
##D                 "MSDE"         "SQLSRV32.DLL"           "03.85.1117"
##D               ODBC_Ver            Server_Name
##D           "03.52.0000"                  "AUK"
## End(Not run)


