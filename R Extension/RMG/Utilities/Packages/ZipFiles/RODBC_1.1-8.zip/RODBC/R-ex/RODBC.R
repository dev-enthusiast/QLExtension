### Name: RODBC
### Title: ODBC Database Connectivity
### Aliases: RODBC
### Keywords: IO database

### ** Examples

## Not run: 
##D channel <- odbcConnect("test")
##D sqlSave(channel, USArrests, rownames = "State", verbose = TRUE)
##D sqlQuery(channel, paste("select State, Murder from USArrests",
##D                         "where Rape > 30 order by Murder"))
##D sqlFetch(channel, "USArrests", rownames = "State")
##D sqlDrop(channel, "USArrests")
##D close(channel)
## End(Not run)


