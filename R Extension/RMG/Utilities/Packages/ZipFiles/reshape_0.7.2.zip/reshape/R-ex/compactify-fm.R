### Name: compactify
### Title: Compactify
### Aliases: compactify
### Keywords: internal

### ** Examples



