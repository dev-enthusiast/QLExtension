### Name: recast
### Title: Recast
### Aliases: recast
### Keywords: manip

### ** Examples
recast(french_fries, time ~ variable, id.var=1:4)


