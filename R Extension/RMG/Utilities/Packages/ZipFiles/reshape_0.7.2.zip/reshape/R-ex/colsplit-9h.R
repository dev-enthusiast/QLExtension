### Name: colsplit
### Title: Split a vector into multiple columns
### Aliases: colsplit colsplit.factor colsplit.character
### Keywords: manip

### ** Examples



