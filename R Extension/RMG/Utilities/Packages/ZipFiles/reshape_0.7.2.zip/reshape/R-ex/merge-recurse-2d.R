### Name: merge_recurse
### Title: Recursively merge data frames
### Aliases: merge_recurse
### Keywords: internal

### ** Examples



