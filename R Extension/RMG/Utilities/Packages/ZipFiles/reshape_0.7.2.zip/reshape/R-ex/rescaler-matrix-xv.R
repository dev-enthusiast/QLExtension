### Name: rescaler.matrix
### Title: Rescale a matrix
### Aliases: rescaler.matrix
### Keywords: internal

### ** Examples



