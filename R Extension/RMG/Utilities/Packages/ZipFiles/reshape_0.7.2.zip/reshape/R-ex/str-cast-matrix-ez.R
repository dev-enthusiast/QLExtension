### Name: str.cast_matrix
### Title: Printing methods
### Aliases: str.cast_matrix str.cast_df print.cast_matrix print.cast_df
### Keywords: internal

### ** Examples



