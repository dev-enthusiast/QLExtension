### Name: compute.margins
### Title: Compute margins
### Aliases: compute.margins
### Keywords: internal

### ** Examples



