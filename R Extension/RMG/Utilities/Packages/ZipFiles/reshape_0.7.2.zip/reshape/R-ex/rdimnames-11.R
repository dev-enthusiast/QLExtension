### Name: rdimnames
### Title: Dimension names
### Aliases: rdimnames rdimnames<- rcolnames rcolnames<- rrownames
###   rrownames<-
### Keywords: internal

### ** Examples



