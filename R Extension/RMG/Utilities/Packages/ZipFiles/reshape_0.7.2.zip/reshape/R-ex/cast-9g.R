### Name: cast
### Title: Cast function
### Aliases: cast
### Keywords: manip

### ** Examples
#Air quality example
names(airquality) <- tolower(names(airquality))
airquality.d <- melt(airquality, id=c("month", "day"), preserve.na=FALSE)

cast(airquality.d, day ~ month ~ variable)
cast(airquality.d, month ~ variable, mean)
cast(airquality.d, month ~ . | variable, mean)
cast(airquality.d, month ~ variable, mean, margins=c("grand_row", "grand_col"))
cast(airquality.d, day ~ month, mean, subset=variable=="ozone")
cast(airquality.d, month ~ variable, range)
cast(airquality.d, month ~ variable + result_variable, range)
cast(airquality.d, variable ~ month ~ result_variable,range)

#Chick weight example
names(ChickWeight) <- tolower(names(ChickWeight))
chick.d <- melt(ChickWeight, id=2:4, preserve.na = FALSE)

cast(chick.d, time ~ variable, mean) # average effect of time
cast(chick.d, diet ~ variable, mean) # average effect of diet
cast(chick.d, diet ~ time ~ variable, mean) # average effect of diet & time

# How many chicks at each time? - checking for balance
cast(chick.d, time ~ diet, length)
cast(chick.d, chick ~ time, mean)
cast(chick.d, chick ~ time, mean, subset=time < 10 & chick < 20)

cast(chick.d, diet + chick ~ time)
cast(chick.d, chick ~ time ~ diet)
cast(chick.d, diet + chick ~ time, mean, margins="diet")

#Tips example
cast(melt(tips), sex ~ smoker, mean, subset=variable=="total_bill")
cast(melt(tips), sex ~ smoker | variable, mean)

ff_d <- melt(french_fries, id=1:4, preserve.na=FALSE)
cast(ff_d, subject ~ time, length)
cast(ff_d, subject ~ time, length, fill=0)
cast(ff_d, subject ~ time, function(x) 30 - length(x))
cast(ff_d, subject ~ time, function(x) 30 - length(x), fill=30)
cast(ff_d, variable ~ ., c(min, max))
cast(ff_d, variable ~ ., function(x) quantile(x,c(0.25,0.5)))
cast(ff_d, treatment ~ variable, mean, margins=c("grand_col", "grand_row"))
cast(ff_d, treatment + subject ~ variable, mean, margins="treatment")
lattice::xyplot(X1 ~ X2 | variable, cast(ff_d, ... ~ rep), aspect="iso")


