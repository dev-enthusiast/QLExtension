### Name: reorder_factor
### Title: Reorder factor levels
### Aliases: reorder_factor
### Keywords: manip

### ** Examples
df <- data.frame(a = LETTERS[sample(5, 15, replace=TRUE)], y = rnorm(15))     
(f <- reorder_factor(df$a, tapply(df$y, df$a, mean)))
(f <- reorder_factor(f))
reorder_factor(f, c(4,2,3,1,5), dec=TRUE)


