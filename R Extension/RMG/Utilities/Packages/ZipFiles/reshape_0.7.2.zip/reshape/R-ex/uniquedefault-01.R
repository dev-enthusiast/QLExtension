### Name: uniquedefault
### Title: Unique default
### Aliases: uniquedefault
### Keywords: manip

### ** Examples



