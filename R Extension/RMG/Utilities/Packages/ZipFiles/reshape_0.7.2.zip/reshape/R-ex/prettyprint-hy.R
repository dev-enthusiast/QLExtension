### Name: prettyprint
### Title: Print reshaped data frame
### Aliases: prettyprint
### Keywords: internal

### ** Examples



