### Name: as.data.frame.cast_matrix
### Title: Convert cast matrix into a data frame
### Aliases: as.data.frame.cast_matrix
### Keywords: internal

### ** Examples



