### Name: as.matrix.cast_df
### Title: Convert cast data.frame into a matrix
### Aliases: as.matrix.cast_df
### Keywords: internal

### ** Examples



