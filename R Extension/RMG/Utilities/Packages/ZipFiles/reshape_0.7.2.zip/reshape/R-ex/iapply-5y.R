### Name: iapply
### Title: Idempotent apply
### Aliases: iapply
### Keywords: manip

### ** Examples
a <- array(1:27, c(2,3,4))
all.equal(a, iapply(a, 1, force))
all.equal(a, iapply(a, 2, force))
all.equal(a, iapply(a, 3, force))
all.equal(a, iapply(a, 1:2, force))
all.equal(aperm(a, c(2,1,3)), iapply(a, 2, force, REORDER=FALSE))
all.equal(aperm(a, c(3,1,2)), iapply(a, 3, force, REORDER=FALSE))

iapply(a, 1, min)
iapply(a, 1, min, DROP=TRUE)
iapply(a, 2, min)
iapply(a, 2, min, DROP=TRUE)
iapply(a, 3, min)
iapply(a, 3, min, DROP=TRUE)
iapply(a, 1, range)
iapply(a, 2, range)
iapply(a, 3, range)

mina <- iapply(a, 1, min)
sweep(a, 1, mina)
mina <- iapply(a, c(1,3), min)
sweep(a, c(1,3), mina)


