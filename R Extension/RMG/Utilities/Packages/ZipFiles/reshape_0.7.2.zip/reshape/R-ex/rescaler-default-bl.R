### Name: rescaler.default
### Title: Default rescaler
### Aliases: rescaler.default
### Keywords: internal

### ** Examples



