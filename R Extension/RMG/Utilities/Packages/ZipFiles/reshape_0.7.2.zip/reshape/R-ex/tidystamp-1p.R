### Name: tidystamp
### Title: Tidy up stamped data set
### Aliases: tidystamp
### Keywords: internal

### ** Examples



