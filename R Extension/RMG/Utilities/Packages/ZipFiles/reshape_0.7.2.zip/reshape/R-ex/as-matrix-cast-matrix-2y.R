### Name: as.matrix.cast_matrix
### Title: Convert cast matrix into a matrix
### Aliases: as.matrix.cast_matrix
### Keywords: internal

### ** Examples



