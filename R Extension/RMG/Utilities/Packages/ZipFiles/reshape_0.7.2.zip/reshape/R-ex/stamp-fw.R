### Name: stamp
### Title: Stamp
### Aliases: stamp
### Keywords: manip

### ** Examples
french_fries$time <- as.numeric(as.character(french_fries$time))
stamp(french_fries, subject ~ ., function(df) coef(lm(painty ~ time, df))[2])
stamp(french_fries, subject ~ treatment, function(df) coef(lm(painty ~ time, df))[2])
models <- stamp(french_fries, subject ~ ., function(df) lm(painty ~ time, df))
dim(models)
anova(models[[3,1]])


