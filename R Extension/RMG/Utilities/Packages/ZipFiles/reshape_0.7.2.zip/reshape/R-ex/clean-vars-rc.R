### Name: clean.vars
### Title: Clean variables.
### Aliases: clean.vars
### Keywords: internal

### ** Examples



