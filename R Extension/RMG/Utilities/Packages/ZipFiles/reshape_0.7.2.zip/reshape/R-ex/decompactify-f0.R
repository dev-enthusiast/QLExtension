### Name: decompactify
### Title: Decompactify
### Aliases: decompactify
### Keywords: internal

### ** Examples



