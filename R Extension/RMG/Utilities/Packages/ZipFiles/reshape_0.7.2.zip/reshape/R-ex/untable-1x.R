### Name: untable
### Title: Untable a dataset
### Aliases: untable
### Keywords: manip

### ** Examples



