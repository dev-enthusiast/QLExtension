### Name: cast_matrix
### Title: Cast matrix.
### Aliases: cast_matrix
### Keywords: internal

### ** Examples



