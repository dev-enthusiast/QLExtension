### Name: condense
### Title: Condense
### Aliases: condense
### Keywords: manip internal

### ** Examples



