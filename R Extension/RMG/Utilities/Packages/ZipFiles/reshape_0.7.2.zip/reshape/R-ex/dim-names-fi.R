### Name: dim_names
### Title: Dimension names
### Aliases: dim_names
### Keywords: internal

### ** Examples



