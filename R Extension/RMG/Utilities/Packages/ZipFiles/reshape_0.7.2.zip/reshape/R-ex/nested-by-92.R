### Name: nested.by
### Title: Nested.by function
### Aliases: nested.by
### Keywords: internal

### ** Examples



