### Name: check_formula
### Title: Check formula
### Aliases: check_formula
### Keywords: internal

### ** Examples



