### Name: condense.df
### Title: Condense a data frame
### Aliases: condense.df
### Keywords: manip

### ** Examples



