### Name: melt.data.frame
### Title: Melt
### Aliases: melt.data.frame
### Keywords: manip

### ** Examples
head(melt(tips))
names(airquality) <- tolower(names(airquality))
airquality.d <- melt(airquality, id=c("month", "day"))
head(airquality.d)
names(ChickWeight) <- tolower(names(ChickWeight))
chick.d <- melt(ChickWeight, id=2:4)


